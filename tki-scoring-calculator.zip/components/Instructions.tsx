import React from 'react';
import { Info } from 'lucide-react';

const Instructions: React.FC = () => {
  return (
    <div className="bg-green-50 rounded-xl p-6 shadow-sm h-full">
      <div className="flex items-center mb-6">
        <div className="bg-green-100 rounded-full p-2 mr-3">
          <Info className="w-5 h-5 text-green-600" />
        </div>
        <h3 className="font-sans text-xl font-bold text-green-800">How to Use This Calculator</h3>
      </div>

      <div className="flex flex-col space-y-4">
        <div className="flex items-start">
          <div className="bg-green-500 text-white rounded-full w-6 h-6 flex items-center justify-center font-sans text-sm font-bold mr-3 flex-shrink-0 mt-0.5">1</div>
          <p className="font-sans text-sm text-gray-700">Count your answers from the assessment (Competing, Collaborating, etc.).</p>
        </div>
        <div className="flex items-start">
          <div className="bg-green-500 text-white rounded-full w-6 h-6 flex items-center justify-center font-sans text-sm font-bold mr-3 flex-shrink-0 mt-0.5">2</div>
          <p className="font-sans text-sm text-gray-700">Enter your scores in the left column input fields.</p>
        </div>
        <div className="flex items-start">
          <div className="bg-green-500 text-white rounded-full w-6 h-6 flex items-center justify-center font-sans text-sm font-bold mr-3 flex-shrink-0 mt-0.5">3</div>
          <p className="font-sans text-sm text-gray-700">Click "Calculate Results" to analyze your conflict style profile.</p>
        </div>
        <div className="flex items-start">
          <div className="bg-green-500 text-white rounded-full w-6 h-6 flex items-center justify-center font-sans text-sm font-bold mr-3 flex-shrink-0 mt-0.5">4</div>
          <p className="font-sans text-sm text-gray-700">Review insights about your dominant, backup, and underused modes.</p>
        </div>
      </div>
    </div>
  );
};

export default Instructions;