import React, { useEffect, useState } from 'react';
import { AnalysisResult } from '../types';
import { MODE_CONFIGS } from '../constants';
import { Lightbulb, Trophy, Handshake, TrendingUp } from 'lucide-react';

interface ResultsViewProps {
  results: AnalysisResult;
}

const ResultsView: React.FC<ResultsViewProps> = ({ results }) => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    setVisible(true);
  }, []);

  const getLabel = (keys: string[]) => {
    if (keys.length === 0) return 'None';
    return keys.map(k => MODE_CONFIGS.find(m => m.key === k)?.label).join(', ');
  };

  return (
    <div className={`bg-indigo-50 rounded-xl p-6 shadow-sm transition-opacity duration-500 ${visible ? 'opacity-100' : 'opacity-0'}`}>
      <div className="flex items-center mb-6">
        <div className="bg-indigo-100 rounded-full p-2 mr-3">
          <Lightbulb className="w-5 h-5 text-indigo-600" />
        </div>
        <h3 className="font-sans text-xl font-bold text-indigo-800">Your Conflict Style Insights</h3>
      </div>

      <div className="space-y-4">
        {/* Dominant */}
        <div className="bg-white rounded-lg p-5 border-l-4 border-yellow-500 shadow-md transform transition-all hover:scale-[1.01]">
          <div className="flex items-center mb-2">
            <div className="bg-yellow-100 rounded-full p-2 mr-3">
              <Trophy className="w-5 h-5 text-yellow-600" />
            </div>
            <div>
              <h4 className="font-sans text-lg font-bold text-gray-800">
                Dominant Mode: <span className="text-yellow-700">{getLabel(results.dominant)}</span>
              </h4>
              <p className="font-sans text-sm text-gray-600">Your default approach under stress</p>
            </div>
          </div>
        </div>

        {/* Backup */}
        <div className="bg-white rounded-lg p-5 border-l-4 border-blue-500 shadow-md transform transition-all hover:scale-[1.01]">
          <div className="flex items-center mb-2">
            <div className="bg-blue-100 rounded-full p-2 mr-3">
              <Handshake className="w-5 h-5 text-blue-600" />
            </div>
             <div>
              <h4 className="font-sans text-lg font-bold text-gray-800">
                Backup Mode: <span className="text-blue-700">{getLabel(results.backup)}</span>
              </h4>
              <p className="font-sans text-sm text-gray-600">Your conscious choice when your dominant mode isn't working</p>
            </div>
          </div>
        </div>

        {/* Underused */}
        <div className="bg-white rounded-lg p-5 border-l-4 border-purple-500 shadow-md transform transition-all hover:scale-[1.01]">
          <div className="flex items-center mb-2">
            <div className="bg-purple-100 rounded-full p-2 mr-3">
              <TrendingUp className="w-5 h-5 text-purple-600" />
            </div>
             <div>
              <h4 className="font-sans text-lg font-bold text-gray-800">
                Underused Modes: <span className="text-purple-700">{getLabel(results.underused)}</span>
              </h4>
              <p className="font-sans text-sm text-gray-600">Development opportunities to expand your repertoire</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ResultsView;