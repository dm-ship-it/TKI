import React, { useState } from 'react';
import { QUESTIONS, INITIAL_SCORES, MODE_CONFIGS } from '../constants';
import { Scores, ModeKey } from '../types';
import { ClipboardCheck, Clock, Brain, BarChart, ArrowLeft } from 'lucide-react';

interface AssessmentProps {
  onComplete: (scores: Scores) => void;
  onCancel: () => void;
}

const Assessment: React.FC<AssessmentProps> = ({ onComplete, onCancel }) => {
  const [answers, setAnswers] = useState<Record<number, ModeKey | null>>({});

  const handleSelect = (questionId: number, mode: ModeKey) => {
    setAnswers(prev => ({
      ...prev,
      [questionId]: mode
    }));
  };

  const calculateAndSubmit = () => {
    // Start with initial scores
    const newScores: Scores = { ...INITIAL_SCORES };
    
    // Sum up scores based on answers
    Object.values(answers).forEach(mode => {
      if (mode) {
        newScores[mode as ModeKey]++;
      }
    });

    onComplete(newScores);
  };

  const isComplete = QUESTIONS.every(q => answers[q.id]);
  const progress = Object.keys(answers).length;
  const total = QUESTIONS.length;

  const getModeColor = (modeKey: ModeKey) => {
    const config = MODE_CONFIGS.find(m => m.key === modeKey);
    return config ? config.color : 'gray';
  };

  return (
    <div className="w-full h-full flex flex-col animate-fadeIn">
      {/* Header Section */}
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-6 gap-4">
        <div className="flex items-center">
          <div className="bg-blue-100 rounded-full p-3 mr-4">
            <ClipboardCheck className="w-6 h-6 text-blue-600" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-gray-800 font-sans">Discover Your Conflict Mode</h2>
            <p className="text-gray-500 text-sm">TKI Assessment</p>
          </div>
        </div>
        <button 
          onClick={onCancel}
          className="text-gray-500 hover:text-gray-700 font-medium text-sm flex items-center"
        >
          <ArrowLeft className="w-4 h-4 mr-1" />
          Back to Calculator
        </button>
      </div>

      {/* Info Banner */}
      <div className="bg-blue-50 rounded-xl p-4 mb-6 flex flex-wrap gap-4 md:gap-8 justify-between items-center shadow-sm border border-blue-100">
        <div className="flex items-center">
          <Clock className="w-5 h-5 text-blue-600 mr-2" />
          <span className="text-sm font-medium text-blue-800">~5 minutes</span>
        </div>
        <div className="flex items-center">
          <Brain className="w-5 h-5 text-blue-600 mr-2" />
          <span className="text-sm font-medium text-blue-800">Choose your first instinct</span>
        </div>
        <div className="flex items-center">
          <BarChart className="w-5 h-5 text-blue-600 mr-2" />
          <span className="text-sm font-medium text-blue-800">{progress}/{total} questions answered</span>
        </div>
      </div>

      {/* Questions Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6 mb-8">
        {QUESTIONS.map((q) => {
          const selectedMode = answers[q.id];
          
          return (
            <div 
              key={q.id} 
              className={`bg-white rounded-lg border p-5 transition-all duration-300 hover:shadow-lg ${selectedMode ? 'border-blue-300 ring-1 ring-blue-100' : 'border-gray-200'}`}
            >
              <div className="text-center mb-4">
                <span className="text-xs font-bold tracking-wider text-gray-500 bg-gray-100 px-3 py-1 rounded-full uppercase">
                  Question {q.id}
                </span>
                <p className="text-sm text-gray-800 mt-3 font-medium min-h-[40px]">{q.text}</p>
              </div>

              <div className="space-y-3">
                {/* Option A */}
                <button
                  onClick={() => handleSelect(q.id, q.optionA.mode)}
                  className={`w-full text-left rounded-lg p-3 transition-all duration-200 flex items-start group relative overflow-hidden
                    ${selectedMode === q.optionA.mode 
                      ? `bg-${getModeColor(q.optionA.mode)}-50 ring-2 ring-${getModeColor(q.optionA.mode)}-500` 
                      : 'bg-white hover:bg-gray-50 border border-gray-100'
                    }`}
                >
                  <div className={`absolute left-0 top-0 bottom-0 w-1 bg-${getModeColor(q.optionA.mode)}-500`} />
                  <span className={`text-xs font-bold mr-2 mt-0.5 text-${getModeColor(q.optionA.mode)}-600`}>A.</span>
                  <p className="text-xs text-gray-700 leading-relaxed">{q.optionA.text}</p>
                </button>

                {/* Option B */}
                <button
                  onClick={() => handleSelect(q.id, q.optionB.mode)}
                  className={`w-full text-left rounded-lg p-3 transition-all duration-200 flex items-start group relative overflow-hidden
                    ${selectedMode === q.optionB.mode 
                      ? `bg-${getModeColor(q.optionB.mode)}-50 ring-2 ring-${getModeColor(q.optionB.mode)}-500` 
                      : 'bg-white hover:bg-gray-50 border border-gray-100'
                    }`}
                >
                  <div className={`absolute left-0 top-0 bottom-0 w-1 bg-${getModeColor(q.optionB.mode)}-500`} />
                  <span className={`text-xs font-bold mr-2 mt-0.5 text-${getModeColor(q.optionB.mode)}-600`}>B.</span>
                  <p className="text-xs text-gray-700 leading-relaxed">{q.optionB.text}</p>
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Submit Section */}
      <div className="mt-auto pt-6 text-center border-t border-gray-100">
        <button
          onClick={calculateAndSubmit}
          disabled={!isComplete}
          className={`px-10 py-3 rounded-lg font-bold shadow-lg transition-all duration-300 transform 
            ${isComplete 
              ? 'bg-blue-600 text-white hover:bg-blue-700 hover:-translate-y-1 hover:shadow-xl cursor-pointer' 
              : 'bg-gray-300 text-gray-500 cursor-not-allowed'
            }`}
        >
          {isComplete ? 'Submit Assessment' : `Answer All Questions (${progress}/${total})`}
        </button>
      </div>
    </div>
  );
};

export default Assessment;