import React from 'react';
import { MODE_CONFIGS } from '../constants';
import { BarChart2 } from 'lucide-react';

const ReferenceTable: React.FC = () => {
  return (
    <div className="bg-blue-50 rounded-xl p-6 shadow-sm">
      <div className="flex items-center mb-6">
        <div className="bg-blue-100 rounded-full p-2 mr-3">
          <BarChart2 className="w-5 h-5 text-blue-600" />
        </div>
        <h3 className="font-sans text-xl font-bold text-blue-800">Interpretation Table</h3>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
        {MODE_CONFIGS.map((mode) => (
          <div key={mode.key} className={`bg-white rounded-lg p-3 border-t-4 border-${mode.color}-500 shadow-sm`}>
            <h4 className={`font-sans text-sm font-semibold text-${mode.color}-700 mb-2`}>
              {mode.label}
            </h4>
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <span className="font-sans text-xs text-gray-600">High</span>
                <span className={`font-sans text-xs font-medium text-${mode.color}-600`}>
                  {mode.thresholds.high}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="font-sans text-xs text-gray-600">Medium</span>
                <span className="font-sans text-xs font-medium text-orange-600">
                  {mode.thresholds.medium}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="font-sans text-xs text-gray-600">Low</span>
                <span className="font-sans text-xs font-medium text-gray-600">
                  {mode.thresholds.low}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ReferenceTable;