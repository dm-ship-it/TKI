import React from 'react';
import { MODE_CONFIGS } from '../constants';
import { Scores, ModeKey } from '../types';
import { Edit2, PieChart, ClipboardList } from 'lucide-react';

interface InputSectionProps {
  scores: Scores;
  onScoreChange: (key: ModeKey, value: number) => void;
  onCalculate: () => void;
  onStartAssessment: () => void;
}

const InputSection: React.FC<InputSectionProps> = ({ scores, onScoreChange, onCalculate, onStartAssessment }) => {
  return (
    <div className="w-full lg:w-1/3 bg-gray-50 rounded-xl p-6 flex flex-col shadow-sm">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center">
          <div className="bg-blue-100 rounded-full p-2 mr-3">
            <Edit2 className="w-5 h-5 text-blue-600" />
          </div>
          <h3 className="font-sans text-xl font-bold text-blue-800">Enter Your Scores</h3>
        </div>
      </div>

      <div className="bg-blue-50 border border-blue-100 rounded-lg p-4 mb-6">
        <h4 className="font-bold text-blue-900 text-sm mb-2">Don't have your scores yet?</h4>
        <button 
          onClick={onStartAssessment}
          className="w-full py-2 bg-white border border-blue-200 hover:border-blue-400 text-blue-700 font-semibold rounded-md shadow-sm flex items-center justify-center transition-all text-sm group"
        >
          <ClipboardList className="w-4 h-4 mr-2 text-blue-500 group-hover:text-blue-700" />
          Take the Assessment
        </button>
      </div>

      <div className="space-y-4 flex-grow">
        {MODE_CONFIGS.map((mode) => {
          // Dynamic class generation based on color prop
          const borderClass = `border-l-4 border-${mode.color}-500`;
          const textLabelClass = `text-${mode.color}-700`;
          const textSubClass = `text-${mode.color}-600`;
          
          return (
            <div 
              key={mode.key}
              className={`bg-white rounded-lg p-4 ${borderClass} shadow-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-md`}
            >
              <div className="flex items-center justify-between mb-2">
                <label className={`font-sans text-sm font-semibold ${textLabelClass}`}>
                  {mode.label}
                </label>
                <span className={`font-sans text-xs ${textSubClass}`}>
                  Max: {mode.maxScore}
                </span>
              </div>
              <input
                className="w-full px-4 py-3 text-lg border border-gray-300 rounded-md font-sans font-medium focus:ring-4 focus:ring-blue-100 focus:border-blue-500 outline-none transition-all"
                type="number"
                min="0"
                max={mode.maxScore}
                placeholder="0"
                value={scores[mode.key] === 0 ? '' : scores[mode.key]}
                onChange={(e) => {
                  const val = parseInt(e.target.value) || 0;
                  onScoreChange(mode.key, val);
                }}
              />
            </div>
          );
        })}
      </div>

      <button
        onClick={onCalculate}
        className="mt-6 w-full py-4 px-6 bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 text-white font-bold rounded-lg shadow-lg flex items-center justify-center transition-all duration-300 transform hover:-translate-y-1"
      >
        <PieChart className="w-5 h-5 mr-2" />
        <span>Calculate Results</span>
      </button>
    </div>
  );
};

export default InputSection;