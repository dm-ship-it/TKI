export type ModeKey = 'competing' | 'collaborating' | 'compromising' | 'avoiding' | 'accommodating';

export interface ModeConfig {
  key: ModeKey;
  label: string;
  color: string; // Tailwind color name (e.g., 'red', 'green')
  iconName: string;
  maxScore: number;
  thresholds: {
    high: string;
    medium: string;
    low: string;
  };
}

export type Scores = Record<ModeKey, number>;

export interface AnalysisResult {
  dominant: ModeKey[];
  backup: ModeKey[];
  underused: ModeKey[];
}

export interface QuestionOption {
  text: string;
  mode: ModeKey;
}

export interface Question {
  id: number;
  text: string;
  optionA: QuestionOption;
  optionB: QuestionOption;
}