import React, { useState } from 'react';
import { Calculator, Timer } from 'lucide-react';
import InputSection from './components/InputSection';
import ReferenceTable from './components/ReferenceTable';
import ResultsView from './components/ResultsView';
import Instructions from './components/Instructions';
import Assessment from './components/Assessment';
import { Scores, ModeKey, AnalysisResult } from './types';
import { INITIAL_SCORES } from './constants';

const App: React.FC = () => {
  const [scores, setScores] = useState<Scores>(INITIAL_SCORES);
  const [hasCalculated, setHasCalculated] = useState(false);
  const [isAssessmentMode, setIsAssessmentMode] = useState(false);
  const [results, setResults] = useState<AnalysisResult>({
    dominant: [],
    backup: [],
    underused: []
  });

  const handleScoreChange = (key: ModeKey, value: number) => {
    setScores(prev => ({
      ...prev,
      [key]: value
    }));
    if (hasCalculated) setHasCalculated(false);
  };

  const calculateResults = (currentScores: Scores = scores) => {
    const scoreValues = Object.values(currentScores) as number[];
    const maxScore = Math.max(...scoreValues);
    const minScore = Math.min(...scoreValues);

    // Identify Dominant (Max Score)
    const dominant = (Object.keys(currentScores) as ModeKey[]).filter(key => currentScores[key] === maxScore);

    // Identify Backup (Second Highest, distinct from Max)
    const uniqueScores = [...new Set(scoreValues)].sort((a, b) => b - a);
    let backup: ModeKey[] = [];
    
    if (uniqueScores.length > 1) {
      const secondHighest = uniqueScores[1];
      backup = (Object.keys(currentScores) as ModeKey[]).filter(key => currentScores[key] === secondHighest);
    }

    // Identify Underused (Min Score)
    const underused = (Object.keys(currentScores) as ModeKey[]).filter(key => currentScores[key] === minScore);

    setResults({ dominant, backup, underused });
    setHasCalculated(true);
  };

  const handleAssessmentComplete = (calculatedScores: Scores) => {
    setScores(calculatedScores);
    calculateResults(calculatedScores);
    setIsAssessmentMode(false);
    // Scroll to top to show results
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-[#667eea] to-[#764ba2] p-4 md:p-8 flex items-center justify-center">
      <div className="w-full max-w-7xl bg-white rounded-2xl shadow-2xl overflow-hidden min-h-[720px] flex flex-col">
        
        {/* Header (Only show if not in assessment mode, or render different header inside Assessment) */}
        {!isAssessmentMode && (
          <div className="p-8 pb-4">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="flex items-center">
                <div className="bg-blue-100 rounded-full p-3 mr-4">
                  <Calculator className="w-8 h-8 text-blue-600" />
                </div>
                <h2 className="font-serif text-3xl font-bold text-gray-800">TKI Scoring Calculator</h2>
              </div>
              
              <div className="flex items-center bg-gray-100 rounded-full px-5 py-2 self-start md:self-auto">
                <Timer className="w-5 h-5 text-blue-600 mr-2" />
                <span className="font-sans text-sm font-medium text-gray-700">3-5 minutes</span>
              </div>
            </div>
          </div>
        )}

        {/* Content Body */}
        <div className="flex flex-col flex-1 p-8 pt-0">
          {isAssessmentMode ? (
            <div className="pt-8">
              <Assessment 
                onComplete={handleAssessmentComplete}
                onCancel={() => setIsAssessmentMode(false)}
              />
            </div>
          ) : (
            <div className="flex flex-col lg:flex-row gap-8 h-full">
              {/* Left Column: Inputs */}
              <InputSection 
                scores={scores}
                onScoreChange={handleScoreChange}
                onCalculate={() => calculateResults()}
                onStartAssessment={() => setIsAssessmentMode(true)}
              />

              {/* Right Column: Reference & Results */}
              <div className="w-full lg:w-2/3 flex flex-col gap-6">
                <ReferenceTable />
                
                <div className="flex-grow">
                  {hasCalculated ? (
                    <ResultsView results={results} />
                  ) : (
                    <Instructions />
                  )}
                </div>
              </div>
            </div>
          )}
        </div>

      </div>
    </div>
  );
};

export default App;