import { ModeConfig, Scores, Question } from './types';

export const MODE_CONFIGS: ModeConfig[] = [
  {
    key: 'competing',
    label: 'Competing',
    color: 'red',
    iconName: 'trophy',
    maxScore: 6,
    thresholds: { high: '4-6', medium: '2-3', low: '0-1' }
  },
  {
    key: 'collaborating',
    label: 'Collaborating',
    color: 'green',
    iconName: 'handshake',
    maxScore: 8,
    thresholds: { high: '5-8', medium: '3-4', low: '0-2' }
  },
  {
    key: 'compromising',
    label: 'Compromising',
    color: 'orange',
    iconName: 'scale',
    maxScore: 4,
    thresholds: { high: '3-4', medium: '2', low: '0-1' }
  },
  {
    key: 'avoiding',
    label: 'Avoiding',
    color: 'gray',
    iconName: 'shield-off',
    maxScore: 3,
    thresholds: { high: '3', medium: '2', low: '0-1' }
  },
  {
    key: 'accommodating',
    label: 'Accommodating',
    color: 'purple',
    iconName: 'heart-handshake',
    maxScore: 3,
    thresholds: { high: '3', medium: '2', low: '0-1' }
  }
];

export const INITIAL_SCORES: Scores = {
  competing: 0,
  collaborating: 0,
  compromising: 0,
  avoiding: 0,
  accommodating: 0
};

export const QUESTIONS: Question[] = [
  {
    id: 1,
    text: "When priorities clash between regions...",
    optionA: { text: "I push for my region's approach", mode: 'competing' },
    optionB: { text: "I look for a solution that works for everyone", mode: 'collaborating' }
  },
  {
    id: 2,
    text: "When team members disagree on launch timing...",
    optionA: { text: "I facilitate discussion until consensus emerges", mode: 'collaborating' },
    optionB: { text: "I suggest we meet halfway", mode: 'compromising' }
  },
  {
    id: 3,
    text: "When someone challenges your decision...",
    optionA: { text: "I stand firm and explain my rationale", mode: 'competing' },
    optionB: { text: "I consider if they might be right and adjust", mode: 'accommodating' }
  },
  {
    id: 4,
    text: "When there's tension in a meeting...",
    optionA: { text: "I change the subject to avoid escalation", mode: 'avoiding' },
    optionB: { text: "I address it directly and work through it", mode: 'collaborating' }
  },
  {
    id: 5,
    text: "When two team members have personality conflicts...",
    optionA: { text: "I let them work it out themselves", mode: 'avoiding' },
    optionB: { text: "I mediate to find common ground", mode: 'compromising' }
  },
  {
    id: 6,
    text: "When budget cuts are necessary...",
    optionA: { text: "I make the tough call quickly", mode: 'competing' },
    optionB: { text: "I involve the team in prioritization", mode: 'collaborating' }
  },
  {
    id: 7,
    text: "When your approach differs from your peer's...",
    optionA: { text: "I defer to their expertise", mode: 'accommodating' },
    optionB: { text: "I propose we pilot both approaches", mode: 'compromising' }
  },
  {
    id: 8,
    text: "When meeting becomes heated debate...",
    optionA: { text: "I table the discussion for later", mode: 'avoiding' },
    optionB: { text: "I enforce ground rules and continue", mode: 'competing' }
  },
  {
    id: 9,
    text: "When cross-functional alignment is needed...",
    optionA: { text: "I invest time to understand all perspectives", mode: 'collaborating' },
    optionB: { text: "I propose a practical middle ground", mode: 'compromising' }
  },
  {
    id: 10,
    text: "When your team member needs development...",
    optionA: { text: "I give direct feedback immediately", mode: 'competing' },
    optionB: { text: "I coach them to their own insights", mode: 'collaborating' }
  },
  {
    id: 11,
    text: "When stakeholders want different outcomes...",
    optionA: { text: "I support the relationship that matters most", mode: 'accommodating' },
    optionB: { text: "I find creative ways to satisfy both", mode: 'collaborating' }
  },
  {
    id: 12,
    text: "When facing resistance to change...",
    optionA: { text: "I implement despite objections", mode: 'competing' },
    optionB: { text: "I engage resistors to co-create solutions", mode: 'collaborating' }
  }
];